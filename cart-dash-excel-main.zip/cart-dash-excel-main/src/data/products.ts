import { Product } from '@/types/product';

export const products: Product[] = [
  // Featured Products
  { id: 1,  name: "Burger with Onion",  price: 780,  category: "featured",  image: "cart-dash-excel/src/data/BURGERWITHOINION.png"},
  { id: 2, name: "Beef Biryani", price: 390, category: 'featured', image: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=400' },
  { id: 3, name: "Chicken Fajita Pizza", price: 1250, category: 'featured', image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?w=400' },
  { id: 4, name: "Chicken Paratha", price: 250, category: 'featured', image: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?w=400' },
  { id: 5, name: "Chicken Leg Broast", price: 1250, category: 'featured', image: 'https://images.unsplash.com/photo-1626082927389-6cd097cdc6ec?w=400' },
  { id: 6, name: "Fruit Ball", price: 250, category: 'featured', image: 'https://images.unsplash.com/photo-1587132160859-22afd35c3e80?w=400' },

  // Popular Products
  { id: 7, name: "Zinger Burger", price: 850, category: 'popular', image: 'https://images.unsplash.com/photo-1550547660-d9450f859349?w=400' },
  { id: 8, name: "Crispy Chicken Wrap", price: 620, category: 'popular', image: 'https://images.unsplash.com/photo-1626700051175-6818013e1d4f?w=400' },
  { id: 9, name: "Cheese Pizza", price: 1100, category: 'popular', image: 'https://images.unsplash.com/photo-1571997478779-2adcbbe9ab2f?w=400' },
  { id: 10, name: "Beef Steak", price: 1550, category: 'popular', image: 'https://images.unsplash.com/photo-1600891964092-4316c288032e?w=400' },

  // Fast Food
  { id: 11, name: "Club Sandwich", price: 600, category: 'fastfood', image: 'https://images.unsplash.com/photo-1528735602780-2552fd46c7af?w=400' },
  { id: 12, name: "Grilled Burger", price: 750, category: 'fastfood', image: 'https://images.unsplash.com/photo-1553979459-d2229ba7433b?w=400' },
  { id: 13, name: "Loaded Fries", price: 450, category: 'fastfood', image: 'https://images.unsplash.com/photo-1573080496219-bb080dd4f877?w=400' },
  { id: 14, name: "BBQ Roll", price: 500, category: 'fastfood', image: 'https://images.unsplash.com/photo-1599487488170-d11ec9c172f0?w=400' },

  // Cakes & Bakery
  { id: 15, name: "Chocolate Cake", price: 1200, category: 'bakery', image: 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=400' },
  { id: 16, name: "Cupcakes Box", price: 800, category: 'bakery', image: 'https://images.unsplash.com/photo-1614707267537-b85aaf00c4b7?w=400' },
  { id: 17, name: "Cream Donuts", price: 550, category: 'bakery', image: 'https://images.unsplash.com/photo-1551024601-bec78aea704b?w=400' },
  { id: 18, name: "Cream Roll", price: 250, category: 'bakery', image: 'https://images.unsplash.com/photo-1509365390695-33aee754c6f6?w=400' },

  // Ready to Cook
  { id: 19, name: "Marinated Chicken Tikka", price: 900, category: 'readytocook', image: 'https://images.unsplash.com/photo-1599487488170-d11ec9c172f0?w=400' },
  { id: 20, name: "Seekh Kabab (Ready to Fry)", price: 700, category: 'readytocook', image: 'https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?w=400' },
  { id: 21, name: "Nuggets (Frozen)", price: 600, category: 'readytocook', image: 'https://images.unsplash.com/photo-1562967914-608f82629710?w=400' },
  { id: 22, name: "Fish Fillet", price: 1100, category: 'readytocook', image: 'https://images.unsplash.com/photo-1534604973900-c43ab4c2e0ab?w=400' },

  // Desi Food
  { id: 23, name: "Chicken Karahi", price: 1250, category: 'desi', image: 'https://images.unsplash.com/photo-1631452180519-c014fe946bc7?w=400' },
  { id: 24, name: "Beef Nihari", price: 900, category: 'desi', image: 'https://images.unsplash.com/photo-1585937421612-70a008356fbe?w=400' },
  { id: 25, name: "Mutton Biryani", price: 950, category: 'desi', image: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=400' },
  { id: 26, name: "Haleem Bowl", price: 450, category: 'desi', image: 'https://images.unsplash.com/photo-1645177628172-a94c30a5e74f?w=400' },
];
