import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { CartItem, Product, Order } from '@/types/product';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

interface CartContextType {
  cart: CartItem[];
  orders: Order[];
  addToCart: (product: Product) => void;
  removeFromCart: (productId: number) => void;
  updateQuantity: (productId: number, quantity: number) => void;
  clearCart: () => void;
  placeOrder: (customerInfo: Omit<Order, 'id' | 'date' | 'time' | 'items' | 'total' | 'status'>) => Promise<Order>;
  updateOrderStatus: (orderId: string, status: Order['status']) => void;
  deleteOrder: (orderId: string) => void;
  getCartTotal: () => number;
  getCartCount: () => number;
  isLoadingOrders: boolean;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export function CartProvider({ children }: { children: ReactNode }) {
  const { isAdmin, user } = useAuth();
  const [cart, setCart] = useState<CartItem[]>(() => {
    const saved = localStorage.getItem('food-passion-cart');
    return saved ? JSON.parse(saved) : [];
  });

  const [orders, setOrders] = useState<Order[]>([]);
  const [isLoadingOrders, setIsLoadingOrders] = useState(false);

  useEffect(() => {
    localStorage.setItem('food-passion-cart', JSON.stringify(cart));
  }, [cart]);

  // Fetch orders from Supabase for admin users
  useEffect(() => {
    if (isAdmin && user) {
      fetchOrders();
    }
  }, [isAdmin, user]);

  const fetchOrders = async () => {
    setIsLoadingOrders(true);
    try {
      const { data, error } = await supabase
        .from('orders')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching orders:', error);
        return;
      }

      if (data) {
        const mappedOrders: Order[] = data.map((order) => ({
          id: order.id,
          date: order.date,
          time: order.time,
          customerName: order.customer_name,
          customerContact: order.customer_contact,
          customerAddress: order.customer_address,
          paymentMethod: order.payment_method,
          items: order.items as unknown as CartItem[],
          total: Number(order.total),
          status: order.status as Order['status'],
        }));
        setOrders(mappedOrders);
      }
    } finally {
      setIsLoadingOrders(false);
    }
  };

  const addToCart = (product: Product) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item =>
          item.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prev, { ...product, quantity: 1 }];
    });
  };

  const removeFromCart = (productId: number) => {
    setCart(prev => prev.filter(item => item.id !== productId));
  };

  const updateQuantity = (productId: number, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart(prev =>
      prev.map(item =>
        item.id === productId ? { ...item, quantity } : item
      )
    );
  };

  const clearCart = () => {
    setCart([]);
  };

  const placeOrder = async (customerInfo: Omit<Order, 'id' | 'date' | 'time' | 'items' | 'total' | 'status'>): Promise<Order> => {
    const now = new Date();
    const orderId = `ORD-${Math.floor(10000 + Math.random() * 90000)}`;
    const order: Order = {
      id: orderId,
      date: now.toLocaleDateString('en-GB'),
      time: now.toLocaleTimeString(),
      items: [...cart],
      total: getCartTotal(),
      status: 'pending',
      ...customerInfo,
    };

    // Save to Supabase
    const { error } = await supabase.from('orders').insert([{
      id: order.id,
      date: order.date,
      time: order.time,
      customer_name: order.customerName,
      customer_contact: order.customerContact,
      customer_address: order.customerAddress,
      payment_method: order.paymentMethod,
      items: JSON.parse(JSON.stringify(order.items)),
      total: order.total,
      status: order.status,
      user_id: user?.id,
    }]);

    if (error) {
      console.error('Error saving order:', error);
      throw error;
    }

    clearCart();
    return order;
  };

  const getCartTotal = () => {
    return cart.reduce((total, item) => total + item.price * item.quantity, 0);
  };

  const getCartCount = () => {
    return cart.reduce((count, item) => count + item.quantity, 0);
  };

  const updateOrderStatus = async (orderId: string, status: Order['status']) => {
    const { error } = await supabase
      .from('orders')
      .update({ status })
      .eq('id', orderId);

    if (error) {
      console.error('Error updating order status:', error);
      return;
    }

    setOrders(prev =>
      prev.map(order =>
        order.id === orderId ? { ...order, status } : order
      )
    );
  };

  const deleteOrder = async (orderId: string) => {
    const { error } = await supabase
      .from('orders')
      .delete()
      .eq('id', orderId);

    if (error) {
      console.error('Error deleting order:', error);
      return;
    }

    setOrders(prev => prev.filter(order => order.id !== orderId));
  };

  return (
    <CartContext.Provider
      value={{
        cart,
        orders,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        placeOrder,
        updateOrderStatus,
        deleteOrder,
        getCartTotal,
        getCartCount,
        isLoadingOrders,
      }}
    >
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart must be used within CartProvider');
  }
  return context;
}
