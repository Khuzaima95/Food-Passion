import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/hooks/use-toast';

export interface Review {
  id: string;
  user_id: string;
  product_id: number;
  rating: number;
  comment: string | null;
  created_at: string;
  user_email?: string;
}

export function useReviews(productId?: number) {
  const { user } = useAuth();
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);
  const [averageRating, setAverageRating] = useState(0);
  const [userReview, setUserReview] = useState<Review | null>(null);

  const fetchReviews = useCallback(async () => {
    if (!productId) {
      setLoading(false);
      return;
    }

    try {
      const { data, error } = await supabase
        .from('reviews')
        .select('*')
        .eq('product_id', productId)
        .order('created_at', { ascending: false });

      if (error) throw error;

      // Get user emails from profiles
      const userIds = [...new Set(data?.map(r => r.user_id) || [])];
      let userEmails: Record<string, string> = {};
      
      if (userIds.length > 0) {
        const { data: profiles } = await supabase
          .from('profiles')
          .select('id, email')
          .in('id', userIds);
        
        profiles?.forEach(p => {
          if (p.email) userEmails[p.id] = p.email;
        });
      }

      const reviewsWithEmail = data?.map(review => ({
        ...review,
        user_email: userEmails[review.user_id] || 'Anonymous',
      })) || [];

      setReviews(reviewsWithEmail);

      // Calculate average rating
      if (reviewsWithEmail.length > 0) {
        const avg = reviewsWithEmail.reduce((sum, r) => sum + r.rating, 0) / reviewsWithEmail.length;
        setAverageRating(Math.round(avg * 10) / 10);
      }

      // Find user's review
      if (user) {
        const myReview = reviewsWithEmail.find(r => r.user_id === user.id);
        setUserReview(myReview || null);
      }
    } catch (error) {
      console.error('Error fetching reviews:', error);
    } finally {
      setLoading(false);
    }
  }, [productId, user]);

  useEffect(() => {
    fetchReviews();
  }, [fetchReviews]);

  const addReview = async (rating: number, comment?: string) => {
    if (!user) {
      toast({
        title: 'Sign in required',
        description: 'Please sign in to leave a review',
        variant: 'destructive',
      });
      return false;
    }

    if (!productId) return false;

    try {
      const { error } = await supabase
        .from('reviews')
        .insert({
          user_id: user.id,
          product_id: productId,
          rating,
          comment: comment || null,
        });

      if (error) throw error;

      toast({
        title: 'Review submitted',
        description: 'Thank you for your feedback!',
      });
      
      await fetchReviews();
      return true;
    } catch (error: any) {
      console.error('Error adding review:', error);
      toast({
        title: 'Error',
        description: 'Failed to submit review',
        variant: 'destructive',
      });
      return false;
    }
  };

  const updateReview = async (reviewId: string, rating: number, comment?: string) => {
    if (!user) return false;

    try {
      const { error } = await supabase
        .from('reviews')
        .update({ rating, comment: comment || null })
        .eq('id', reviewId)
        .eq('user_id', user.id);

      if (error) throw error;

      toast({
        title: 'Review updated',
        description: 'Your review has been updated',
      });
      
      await fetchReviews();
      return true;
    } catch (error) {
      console.error('Error updating review:', error);
      toast({
        title: 'Error',
        description: 'Failed to update review',
        variant: 'destructive',
      });
      return false;
    }
  };

  const deleteReview = async (reviewId: string) => {
    if (!user) return false;

    try {
      const { error } = await supabase
        .from('reviews')
        .delete()
        .eq('id', reviewId)
        .eq('user_id', user.id);

      if (error) throw error;

      toast({
        title: 'Review deleted',
        description: 'Your review has been removed',
      });
      
      await fetchReviews();
      return true;
    } catch (error) {
      console.error('Error deleting review:', error);
      toast({
        title: 'Error',
        description: 'Failed to delete review',
        variant: 'destructive',
      });
      return false;
    }
  };

  return {
    reviews,
    loading,
    averageRating,
    userReview,
    addReview,
    updateReview,
    deleteReview,
    refetch: fetchReviews,
  };
}