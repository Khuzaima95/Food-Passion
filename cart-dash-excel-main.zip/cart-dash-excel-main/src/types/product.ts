export interface Product {
  id: number;
  name: string;
  price: number;
  category: 'featured' | 'popular' | 'fastfood' | 'desi' | 'bakery' | 'readytocook';
  image: string;
}

export interface CartItem extends Product {
  quantity: number;
}

export interface Order {
  id: string;
  date: string;
  time: string;
  customerName: string;
  customerContact: string;
  customerAddress: string;
  paymentMethod: string;
  items: CartItem[];
  total: number;
  status: 'pending' | 'processing' | 'completed' | 'cancelled';
}
