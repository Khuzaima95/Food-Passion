import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useCart } from '@/contexts/CartContext';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { toast } from '@/hooks/use-toast';
import { Order } from '@/types/product';
import { supabase } from '@/integrations/supabase/client';

interface CheckoutModalProps {
  open: boolean;
  onClose: () => void;
  onSuccess: (order: Order) => void;
}

export function CheckoutModal({ open, onClose, onSuccess }: CheckoutModalProps) {
  const { placeOrder, cart, getCartTotal } = useCart();
  const { user, session } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    customerName: '',
    customerEmail: '',
    customerContact: '',
    customerAddress: '',
    paymentMethod: 'Cash on Delivery',
  });

  const sendOrderConfirmationEmail = async (order: Order) => {
    try {
      console.log('Sending order confirmation email...');
      
      const { data, error } = await supabase.functions.invoke('send-order-confirmation', {
        body: {
          orderId: order.id,
          customerName: formData.customerName,
          customerEmail: formData.customerEmail,
          customerPhone: formData.customerContact,
          customerAddress: formData.customerAddress,
          items: cart.map(item => ({
            name: item.name,
            quantity: item.quantity,
            price: item.price * item.quantity,
          })),
          total: getCartTotal(),
          paymentMethod: formData.paymentMethod,
        },
      });

      if (error) {
        console.error('Error sending email:', error);
        toast({
          title: 'Order placed',
          description: 'Your order was placed but we could not send the confirmation email.',
        });
      } else {
        console.log('Email sent successfully:', data);
        toast({
          title: 'Confirmation sent!',
          description: `Order confirmation has been sent to ${formData.customerEmail}`,
        });
      }
    } catch (error) {
      console.error('Error invoking email function:', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.customerName || !formData.customerEmail || !formData.customerContact || !formData.customerAddress) {
      toast({
        title: 'Error',
        description: 'Please fill all required fields',
        variant: 'destructive',
      });
      return;
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.customerEmail)) {
      toast({
        title: 'Error',
        description: 'Please enter a valid email address',
        variant: 'destructive',
      });
      return;
    }

    if (cart.length === 0) {
      toast({
        title: 'Error',
        description: 'Your cart is empty',
        variant: 'destructive',
      });
      return;
    }

    // Enforce Google sign-in before placing an order
    if (!user || !session) {
      toast({
        title: 'Sign in required',
        description: 'Please sign in with Google before placing an order.',
        variant: 'destructive',
      });
      onClose();
      navigate('/auth');
      return;
    }

    const provider = (session.user as any)?.app_metadata?.provider;
    if (provider !== 'google') {
      toast({
        title: 'Google sign-in required',
        description: 'You must sign in with your Google account to place an order.',
        variant: 'destructive',
      });
      onClose();
      navigate('/auth');
      return;
    }

    setLoading(true);

    try {
      const order = await placeOrder(formData);
      
      toast({
        title: 'Order Placed Successfully!',
        description: `Order #${order.id} has been placed`,
      });

      // Send confirmation email
      await sendOrderConfirmationEmail(order);

      onSuccess(order);
      onClose();
      setFormData({
        customerName: '',
        customerEmail: '',
        customerContact: '',
        customerAddress: '',
        paymentMethod: 'Cash on Delivery',
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to place order. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-2xl">Customer Details</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Full Name *</Label>
            <Input
              id="name"
              value={formData.customerName}
              onChange={(e) =>
                setFormData({ ...formData, customerName: e.target.value })
              }
              placeholder="John Doe"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="email">Email Address *</Label>
            <Input
              id="email"
              type="email"
              value={formData.customerEmail}
              onChange={(e) =>
                setFormData({ ...formData, customerEmail: e.target.value })
              }
              placeholder="john@example.com"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="contact">Contact Number *</Label>
            <Input
              id="contact"
              type="tel"
              value={formData.customerContact}
              onChange={(e) =>
                setFormData({ ...formData, customerContact: e.target.value })
              }
              placeholder="+92 300 0000000"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="address">Delivery Address *</Label>
            <Textarea
              id="address"
              value={formData.customerAddress}
              onChange={(e) =>
                setFormData({ ...formData, customerAddress: e.target.value })
              }
              placeholder="Enter your complete delivery address"
              required
              rows={3}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="payment">Payment Method</Label>
            <Select
              value={formData.paymentMethod}
              onValueChange={(value) =>
                setFormData({ ...formData, paymentMethod: value })
              }
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Cash on Delivery">Cash on Delivery</SelectItem>
                <SelectItem value="JazzCash">JazzCash</SelectItem>
                <SelectItem value="EasyPaisa">EasyPaisa</SelectItem>
                <SelectItem value="Credit/Debit Card">Credit/Debit Card</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex gap-3 pt-4">
            <Button type="button" variant="outline" onClick={onClose} className="flex-1">
              Cancel
            </Button>
            <Button type="submit" disabled={loading} className="flex-1">
              {loading ? 'Processing...' : 'Place Order'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
