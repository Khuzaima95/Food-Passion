import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Menu, X, ShoppingCart, Search, LogIn, LogOut, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { useCart } from '@/contexts/CartContext';
import { useAuth } from '@/contexts/AuthContext';
import logo from '@/assets/logo.png';

interface NavbarProps {
  onCartClick: () => void;
  searchQuery?: string;
  onSearchChange?: (query: string) => void;
  dark?: boolean;
}

export function Navbar({ onCartClick, searchQuery = '', onSearchChange, dark = false }: NavbarProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const { getCartCount } = useCart();
  const { user, isAdmin, signOut } = useAuth();

  const navLinks = [
    { name: 'HOME', href: '/' },
    { name: 'MENU', href: '/menu' },
    { name: 'ABOUT', href: '/about' },
    { name: 'CONTACT', href: '/#contact' },
  ];

  const headerBg = dark ? 'bg-card border-b border-border' : '';
  const textColor = dark ? 'text-foreground' : 'text-white';
  const logoTextColor = dark ? 'text-foreground' : 'text-white';
  const linkHoverColor = dark ? 'hover:text-primary' : 'hover:text-accent';
  const searchBg = dark ? 'bg-input border-border' : 'bg-white/10 border-white/20';
  const searchTextColor = dark ? 'text-foreground placeholder:text-muted-foreground' : 'text-white placeholder:text-white/60';
  const position = dark ? 'sticky top-0' : 'absolute top-0';

  return (
    <header className={`${position} left-0 w-full z-50 ${headerBg}`}>
      <div className="flex justify-between items-center px-4 sm:px-8 md:px-12 py-4 md:py-6">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-2 sm:gap-4">
          <img src={logo} alt="Food Passion Logo" className="h-12 sm:h-14 md:h-16 w-auto" />
          <h1 className={`text-xl sm:text-2xl md:text-3xl font-bold ${logoTextColor}`}>
            FOOD PASSION
          </h1>
        </Link>

        {/* Desktop Navigation */}
        <nav className={`hidden md:flex items-center gap-4 lg:gap-6 ${textColor} font-medium text-sm lg:text-base`}>
          {navLinks.map((link) => (
            <Link
              key={link.name}
              to={link.href}
              className={`${linkHoverColor} transition-colors`}
            >
              {link.name}
            </Link>
          ))}
          
          {/* Search Bar - Desktop */}
          {onSearchChange && (
            <div className="relative w-48 lg:w-64">
              <Search className={`absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 ${dark ? 'text-muted-foreground' : 'text-white/60'}`} />
              <Input
                type="text"
                placeholder="Search..."
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                className={`pl-9 h-9 text-sm ${searchBg} ${searchTextColor}`}
              />
            </div>
          )}

          <Button
            onClick={onCartClick}
            variant="secondary"
            size="sm"
            className="relative ml-2"
          >
            <ShoppingCart className="h-4 w-4" />
            {getCartCount() > 0 && (
              <span className="absolute -top-2 -right-2 bg-primary text-primary-foreground rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold">
                {getCartCount()}
              </span>
            )}
          </Button>

          {user ? (
            <>
              <Link to="/account">
                <Button variant="secondary" size="sm" className="flex items-center gap-2">
                  <User className="h-4 w-4" />
                  Account
                </Button>
              </Link>
              {isAdmin && (
                <Link to="/admin">
                  <Button variant="secondary" size="sm">
                    Admin
                  </Button>
                </Link>
              )}
              <Button onClick={signOut} variant="secondary" size="sm">
                <LogOut className="h-4 w-4" />
              </Button>
            </>
          ) : (
            <Link to="/auth">
              <Button variant="secondary" size="sm">
                <LogIn className="h-4 w-4 mr-2" />
                Sign In
              </Button>
            </Link>
          )}
        </nav>

        {/* Mobile Menu Button */}
        <div className="flex items-center gap-2 md:hidden">
          {onSearchChange && (
            <Button
              onClick={() => setSearchOpen(!searchOpen)}
              variant="secondary"
              size="sm"
              aria-label="Search"
            >
              <Search className="h-4 w-4" />
            </Button>
          )}
          <Button
            onClick={onCartClick}
            variant="secondary"
            size="sm"
            className="relative"
          >
            <ShoppingCart className="h-4 w-4" />
            {getCartCount() > 0 && (
              <span className="absolute -top-2 -right-2 bg-primary text-primary-foreground rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold">
                {getCartCount()}
              </span>
            )}
          </Button>
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="flex flex-col gap-1"
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? (
              <X className={`w-6 h-6 ${dark ? 'text-foreground' : 'text-white'}`} />
            ) : (
              <Menu className={`w-6 h-6 ${dark ? 'text-foreground' : 'text-white'}`} />
            )}
          </button>
        </div>
      </div>

      {/* Mobile Search Bar */}
      {searchOpen && onSearchChange && (
        <div className={`md:hidden p-4 animate-in slide-in-from-top ${dark ? 'bg-card border-b border-border' : 'bg-black/95'}`}>
          <div className="relative">
            <Search className={`absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 ${dark ? 'text-muted-foreground' : 'text-white/60'}`} />
            <Input
              type="text"
              placeholder="Search products..."
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              className={`pl-9 h-10 ${searchBg} ${searchTextColor}`}
              autoFocus
            />
          </div>
        </div>
      )}

      {/* Mobile Menu Dropdown */}
      {mobileMenuOpen && (
        <div className={`md:hidden p-6 space-y-4 text-center animate-in slide-in-from-top ${dark ? 'bg-card border-b border-border text-foreground' : 'bg-black/95 text-white'}`}>
          {navLinks.map((link) => (
            <Link
              key={link.name}
              to={link.href}
              className={`block transition-colors text-lg ${linkHoverColor}`}
              onClick={() => setMobileMenuOpen(false)}
            >
            {link.name}
          </Link>
        ))}
        
        {/* Auth buttons in mobile menu */}
        <div className="pt-4 border-t border-white/20">
          {user ? (
            <>
              <Link to="/account" onClick={() => setMobileMenuOpen(false)}>
                <Button variant="secondary" size="sm" className="w-full mb-2">
                  <User className="h-4 w-4 mr-2" />
                  My Account
                </Button>
              </Link>
              {isAdmin && (
                <Link to="/admin" onClick={() => setMobileMenuOpen(false)}>
                  <Button variant="secondary" size="sm" className="w-full mb-2">
                    Admin Panel
                  </Button>
                </Link>
              )}
              <Button onClick={() => { signOut(); setMobileMenuOpen(false); }} variant="secondary" size="sm" className="w-full">
                <LogOut className="h-4 w-4 mr-2" />
                Sign Out
              </Button>
            </>
          ) : (
            <Link to="/auth" onClick={() => setMobileMenuOpen(false)}>
              <Button variant="secondary" size="sm" className="w-full">
                <LogIn className="h-4 w-4 mr-2" />
                Sign In
              </Button>
            </Link>
          )}
        </div>
      </div>
    )}
  </header>
);
}
