import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Order } from '@/types/product';
import { CheckCircle2 } from 'lucide-react';
import logo from '@/assets/logo.png';

interface OrderReceiptProps {
  open: boolean;
  onClose: () => void;
  order: Order | null;
}

export function OrderReceipt({ open, onClose, order }: OrderReceiptProps) {
  if (!order) return null;


  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="w-[calc(100%-2rem)] max-w-md mx-auto max-h-[90vh] overflow-y-auto p-4 sm:p-6 print:max-w-full print:max-h-none print:overflow-visible print:shadow-none print:border-0">
        <DialogHeader className="text-center space-y-2 sm:space-y-4 print:space-y-2">
          <div className="flex justify-center">
            <img src={logo} alt="Food Passion Logo" className="h-12 sm:h-16 w-auto" />
          </div>
          <DialogTitle className="text-xl sm:text-2xl font-bold text-primary">
            Food Passion
          </DialogTitle>
          <div className="flex items-center justify-center gap-2 text-green-600">
            <CheckCircle2 className="h-4 w-4 sm:h-5 sm:w-5" />
            <span className="font-semibold text-sm sm:text-base">Order Confirmed!</span>
          </div>
        </DialogHeader>

        <div className="space-y-4 sm:space-y-6 mt-3 sm:mt-4" data-print-receipt>
          {/* Order Details */}
          <div className="space-y-1.5 sm:space-y-2">
            <div className="flex justify-between text-xs sm:text-sm">
              <span className="text-muted-foreground">Order ID:</span>
              <span className="font-semibold">{order.id}</span>
            </div>
            <div className="flex justify-between text-xs sm:text-sm">
              <span className="text-muted-foreground">Date:</span>
              <span className="font-medium">{order.date}</span>
            </div>
            <div className="flex justify-between text-xs sm:text-sm">
              <span className="text-muted-foreground">Time:</span>
              <span className="font-medium">{order.time}</span>
            </div>
          </div>

          <Separator />

          {/* Customer Details */}
          <div className="space-y-2">
            <h3 className="font-semibold text-xs sm:text-sm text-muted-foreground uppercase">Customer Details</h3>
            <div className="space-y-1">
              <p className="text-xs sm:text-sm break-words">
                <span className="font-medium">Name:</span> {order.customerName}
              </p>
              <p className="text-xs sm:text-sm break-words">
                <span className="font-medium">Contact:</span> {order.customerContact}
              </p>
              <p className="text-xs sm:text-sm break-words">
                <span className="font-medium">Address:</span> {order.customerAddress}
              </p>
              <p className="text-xs sm:text-sm">
                <span className="font-medium">Payment:</span> {order.paymentMethod}
              </p>
            </div>
          </div>

          <Separator />

          {/* Order Items */}
          <div className="space-y-2 sm:space-y-3">
            <h3 className="font-semibold text-xs sm:text-sm text-muted-foreground uppercase">Order Items</h3>
            <div className="space-y-2">
              {order.items.map((item, index) => (
                <div key={index} className="flex justify-between text-xs sm:text-sm gap-2">
                  <div className="flex-1 min-w-0">
                    <span className="font-medium break-words">{item.name}</span>
                    <span className="text-muted-foreground"> x{item.quantity}</span>
                  </div>
                  <span className="font-medium whitespace-nowrap">
                    Rs {(item.price * item.quantity).toLocaleString()}
                  </span>
                </div>
              ))}
            </div>
          </div>

          <Separator />

          {/* Total */}
          <div className="flex justify-between items-center text-base sm:text-lg font-bold gap-2">
            <span>Total Amount:</span>
            <span className="text-primary whitespace-nowrap">Rs {order.total.toLocaleString()}</span>
          </div>

          <Separator />

          {/* Footer Message */}
          <div className="text-center space-y-1.5 sm:space-y-2">
            <p className="text-xs sm:text-sm text-muted-foreground">
              Thank you for ordering from Food Passion!
            </p>
            <p className="text-xs text-muted-foreground">
              Fast. Hygienic. Delicious.
            </p>
          </div>

          {/* Action Button */}
          <div className="flex justify-center pt-2">
            <Button
              variant="default"
              className="w-full sm:w-auto sm:min-w-[200px]"
              onClick={onClose}
            >
              Close
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
