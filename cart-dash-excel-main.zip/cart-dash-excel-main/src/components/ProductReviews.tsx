import { useState } from 'react';
import { useReviews } from '@/hooks/useReviews';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Star, User, Loader2, Trash2, Edit2 } from 'lucide-react';
import { format } from 'date-fns';
import { Link } from 'react-router-dom';

interface ProductReviewsProps {
  productId: number;
  productName: string;
}

export function ProductReviews({ productId, productName }: ProductReviewsProps) {
  const { user } = useAuth();
  const { reviews, loading, averageRating, userReview, addReview, updateReview, deleteReview } = useReviews(productId);
  const [rating, setRating] = useState(userReview?.rating || 5);
  const [comment, setComment] = useState(userReview?.comment || '');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [hoveredRating, setHoveredRating] = useState(0);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    if (userReview && isEditing) {
      await updateReview(userReview.id, rating, comment);
      setIsEditing(false);
    } else {
      await addReview(rating, comment);
    }
    
    setIsSubmitting(false);
  };

  const handleDelete = async () => {
    if (!userReview) return;
    setIsSubmitting(true);
    await deleteReview(userReview.id);
    setRating(5);
    setComment('');
    setIsSubmitting(false);
  };

  const handleEdit = () => {
    if (userReview) {
      setRating(userReview.rating);
      setComment(userReview.comment || '');
      setIsEditing(true);
    }
  };

  const renderStars = (value: number, interactive: boolean = false, size: 'sm' | 'md' = 'md') => {
    const stars = [];
    const displayValue = interactive && hoveredRating > 0 ? hoveredRating : value;
    const sizeClass = size === 'sm' ? 'h-4 w-4' : 'h-6 w-6';
    
    for (let i = 1; i <= 5; i++) {
      stars.push(
        <button
          key={i}
          type="button"
          disabled={!interactive}
          className={`${interactive ? 'cursor-pointer hover:scale-110' : 'cursor-default'} transition-transform`}
          onClick={() => interactive && setRating(i)}
          onMouseEnter={() => interactive && setHoveredRating(i)}
          onMouseLeave={() => interactive && setHoveredRating(0)}
        >
          <Star
            className={`${sizeClass} ${
              i <= displayValue
                ? 'fill-yellow-400 text-yellow-400'
                : 'text-gray-300'
            }`}
          />
        </button>
      );
    }
    return <div className="flex gap-1">{stars}</div>;
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="py-8 flex items-center justify-center">
          <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Reviews for {productName}</CardTitle>
          {reviews.length > 0 && (
            <div className="flex items-center gap-2">
              {renderStars(averageRating)}
              <span className="text-lg font-semibold">{averageRating}</span>
              <span className="text-muted-foreground">({reviews.length} reviews)</span>
            </div>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Write Review Form */}
        {user ? (
          userReview && !isEditing ? (
            <div className="bg-muted/50 p-4 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <p className="font-medium">Your Review</p>
                <div className="flex gap-2">
                  <Button variant="ghost" size="sm" onClick={handleEdit}>
                    <Edit2 className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="sm" onClick={handleDelete} disabled={isSubmitting}>
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </div>
              </div>
              {renderStars(userReview.rating)}
              {userReview.comment && <p className="mt-2 text-muted-foreground">{userReview.comment}</p>}
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4 bg-muted/50 p-4 rounded-lg">
              <div>
                <label className="block text-sm font-medium mb-2">
                  {isEditing ? 'Update your rating' : 'Rate this product'}
                </label>
                {renderStars(rating, true)}
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Your review (optional)</label>
                <Textarea
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                  placeholder="Share your experience with this product..."
                  rows={3}
                />
              </div>
              <div className="flex gap-2">
                <Button type="submit" disabled={isSubmitting}>
                  {isSubmitting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                  {isEditing ? 'Update Review' : 'Submit Review'}
                </Button>
                {isEditing && (
                  <Button type="button" variant="outline" onClick={() => setIsEditing(false)}>
                    Cancel
                  </Button>
                )}
              </div>
            </form>
          )
        ) : (
          <div className="bg-muted/50 p-4 rounded-lg text-center">
            <p className="text-muted-foreground mb-2">Sign in to leave a review</p>
            <Link to="/auth">
              <Button variant="outline">Sign In</Button>
            </Link>
          </div>
        )}

        {/* Reviews List */}
        {reviews.length === 0 ? (
          <p className="text-center text-muted-foreground py-4">No reviews yet. Be the first to review!</p>
        ) : (
          <div className="space-y-4">
            {reviews.filter(r => r.user_id !== user?.id).map((review) => (
              <div key={review.id} className="border-b pb-4 last:border-0">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                    <User className="w-5 h-5 text-primary" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <p className="font-medium">{review.user_email?.split('@')[0] || 'Anonymous'}</p>
                      <span className="text-sm text-muted-foreground">
                        {format(new Date(review.created_at), 'MMM d, yyyy')}
                      </span>
                    </div>
                    <div className="mt-1">{renderStars(review.rating, false, 'sm')}</div>
                    {review.comment && <p className="mt-2 text-muted-foreground">{review.comment}</p>}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}