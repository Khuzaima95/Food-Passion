import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import { Order } from '@/types/product';

export function exportOrdersToExcel(orders: Order[]) {
  // Prepare data for Excel
  const excelData = orders.map(order => ({
    'Order ID': order.id,
    'Date': order.date,
    'Time': order.time,
    'Customer Name': order.customerName,
    'Contact': order.customerContact,
    'Address': order.customerAddress,
    'Payment Method': order.paymentMethod,
    'Items': order.items.map(item => `${item.name} (x${item.quantity})`).join(', '),
    'Total Amount': `Rs ${order.total.toLocaleString()}`,
    'Status': order.status.toUpperCase(),
  }));

  // Create worksheet
  const worksheet = XLSX.utils.json_to_sheet(excelData);

  // Set column widths
  const columnWidths = [
    { wch: 15 }, // Order ID
    { wch: 12 }, // Date
    { wch: 12 }, // Time
    { wch: 20 }, // Customer Name
    { wch: 15 }, // Contact
    { wch: 30 }, // Address
    { wch: 18 }, // Payment Method
    { wch: 40 }, // Items
    { wch: 15 }, // Total Amount
    { wch: 12 }, // Status
  ];
  worksheet['!cols'] = columnWidths;

  // Create workbook
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Orders');

  // Generate Excel file
  const excelBuffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
  const blob = new Blob([excelBuffer], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  });

  // Save file
  const fileName = `Food_Passion_Orders_${new Date().toISOString().split('T')[0]}.xlsx`;
  saveAs(blob, fileName);
}
