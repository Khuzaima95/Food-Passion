import { useState, useMemo } from 'react';
import { Navbar } from '@/components/Navbar';
import { ProductCard } from '@/components/ProductCard';
import { CartDrawer } from '@/components/CartDrawer';
import { CheckoutModal } from '@/components/CheckoutModal';
import { OrderReceipt } from '@/components/OrderReceipt';
import { Button } from '@/components/ui/button';
import { products } from '@/data/products';
import { Order } from '@/types/product';

const categories = [
  { id: 'all', label: 'All Items' },
  { id: 'featured', label: 'Featured' },
  { id: 'popular', label: 'Popular' },
  { id: 'fastfood', label: 'Fast Food' },
  { id: 'desi', label: 'Desi Food' },
  { id: 'bakery', label: 'Bakery' },
  { id: 'readytocook', label: 'Ready to Cook' },
];

export default function Menu() {
  const [cartOpen, setCartOpen] = useState(false);
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [receiptOpen, setReceiptOpen] = useState(false);
  const [currentOrder, setCurrentOrder] = useState<Order | null>(null);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredProducts = useMemo(() => {
    let filtered = products;
    
    if (selectedCategory !== 'all') {
      filtered = filtered.filter(p => p.category === selectedCategory);
    }
    
    if (searchQuery) {
      filtered = filtered.filter(p => 
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.category.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }
    
    return filtered;
  }, [selectedCategory, searchQuery]);

  const handleCheckout = () => {
    setCartOpen(false);
    setCheckoutOpen(true);
  };

  const handleOrderSuccess = (order: Order) => {
    setCurrentOrder(order);
    setReceiptOpen(true);
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar 
        onCartClick={() => setCartOpen(true)} 
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        dark={true}
      />

      {/* Menu Header */}
      <section className="pt-24 pb-8 bg-gradient-to-b from-primary/10 to-background">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold text-center mb-2">
            Our Menu
          </h1>
          <p className="text-center text-muted-foreground text-sm sm:text-base">
            Explore our delicious selection
          </p>
        </div>
      </section>

      {/* Category Filter */}
      <section className="py-6 bg-background sticky top-0 z-40 border-b">
        <div className="container mx-auto px-4">
          <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
            {categories.map((cat) => (
              <Button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                variant={selectedCategory === cat.id ? 'default' : 'outline'}
                size="sm"
                className="whitespace-nowrap"
              >
                {cat.label}
              </Button>
            ))}
          </div>
        </div>
      </section>

      {/* Products Grid */}
      <section className="py-8 md:py-12">
        <div className="container mx-auto px-4">
          {filteredProducts.length > 0 ? (
            <div className="grid grid-cols-1 xs:grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
              {filteredProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          ) : (
            <div className="text-center py-16">
              <p className="text-lg text-muted-foreground">
                No products found. Try a different search or category.
              </p>
            </div>
          )}
        </div>
      </section>

      <CartDrawer
        open={cartOpen}
        onClose={() => setCartOpen(false)}
        onCheckout={handleCheckout}
      />

      <CheckoutModal
        open={checkoutOpen}
        onClose={() => setCheckoutOpen(false)}
        onSuccess={handleOrderSuccess}
      />

      {currentOrder && (
        <OrderReceipt
          open={receiptOpen}
          onClose={() => setReceiptOpen(false)}
          order={currentOrder}
        />
      )}
    </div>
  );
}
