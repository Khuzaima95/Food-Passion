import { Navbar } from '@/components/Navbar';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { ChefHat, Clock, Heart, Shield, Truck, Users } from 'lucide-react';

export default function About() {
  const features = [
    {
      icon: ChefHat,
      title: 'Expert Chefs',
      description: 'Our experienced chefs prepare every dish with passion and precision.',
    },
    {
      icon: Heart,
      title: 'Made with Love',
      description: 'Every meal is crafted with care, just like home-cooked food.',
    },
    {
      icon: Shield,
      title: 'Hygienic Preparation',
      description: 'We maintain the highest standards of cleanliness and food safety.',
    },
    {
      icon: Clock,
      title: 'Fresh & Fast',
      description: 'Small-batch cooking ensures freshness with quick delivery.',
    },
    {
      icon: Truck,
      title: 'Quick Delivery',
      description: 'Hot and fresh food delivered right to your doorstep.',
    },
    {
      icon: Users,
      title: 'Community First',
      description: 'Serving our local community with dedication since day one.',
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navbar dark={true} onCartClick={() => {}} />

      {/* Hero Section */}
      <section className="pt-24 pb-16 bg-gradient-to-b from-primary/10 to-background">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6">
            About <span className="text-primary">Food Passion</span>
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto">
            Your trusted partner for delicious, hygienic, and home-style meals delivered fresh to your door.
          </p>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold text-center mb-8">Our Story</h2>
            <div className="prose prose-lg mx-auto text-center text-muted-foreground">
              <p className="mb-6">
                Food Passion started with a simple dream: to bring the taste of authentic, 
                home-cooked meals to busy families and individuals who don't have the time 
                to cook but refuse to compromise on quality.
              </p>
              <p className="mb-6">
                Founded in Lahore, Pakistan, we've grown from a small kitchen operation 
                to a beloved local food service, trusted by thousands of customers who 
                appreciate our commitment to freshness, hygiene, and authentic flavors.
              </p>
              <p>
                Every dish we prepare reflects our passion for food and our dedication 
                to making your dining experience memorable. From traditional desi cuisine 
                to popular fast food favorites, we've got something for everyone.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Why Choose Us</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-shadow">
                <CardContent className="pt-8 pb-6">
                  <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <feature.icon className="w-8 h-8 text-primary" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                  <p className="text-muted-foreground">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-6">Our Mission</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8">
            To serve delicious, affordable, and hygienic food that brings joy to every meal. 
            We believe everyone deserves access to quality food made with fresh ingredients 
            and a lot of love.
          </p>
          <Link to="/menu">
            <Button size="lg">Explore Our Menu</Button>
          </Link>
        </div>
      </section>

      {/* Contact CTA */}
      <section className="py-16 bg-primary text-primary-foreground">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Have Questions?</h2>
          <p className="text-lg opacity-90 mb-6">
            We'd love to hear from you. Reach out to us anytime!
          </p>
          <div className="flex flex-wrap gap-4 justify-center">
            <Link to="/#contact">
              <Button variant="secondary" size="lg">Contact Us</Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}