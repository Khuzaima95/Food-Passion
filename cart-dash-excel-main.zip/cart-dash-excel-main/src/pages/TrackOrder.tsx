import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Navbar } from '@/components/Navbar';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { Package, Clock, MapPin, Phone, CheckCircle2, Loader2, ChefHat, Truck, Home, ArrowLeft } from 'lucide-react';

interface OrderItem {
  id: number;
  name: string;
  price: number;
  quantity: number;
  image: string;
}

interface Order {
  id: string;
  date: string;
  time: string;
  customer_name: string;
  customer_contact: string;
  customer_address: string;
  payment_method: string;
  items: OrderItem[];
  total: number;
  status: string;
}

const orderSteps = [
  { key: 'pending', label: 'Order Placed', icon: Package, description: 'Your order has been received' },
  { key: 'processing', label: 'Preparing', icon: ChefHat, description: 'Chef is preparing your food' },
  { key: 'out_for_delivery', label: 'On the Way', icon: Truck, description: 'Your order is being delivered' },
  { key: 'completed', label: 'Delivered', icon: Home, description: 'Order delivered successfully' },
];

export default function TrackOrder() {
  const { orderId } = useParams<{ orderId: string }>();
  const [order, setOrder] = useState<Order | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchOrder = async () => {
      if (!orderId) {
        setError('Order ID not provided');
        setLoading(false);
        return;
      }

      try {
        const { data, error: fetchError } = await supabase
          .from('orders')
          .select('*')
          .eq('id', orderId)
          .single();

        if (fetchError) throw fetchError;

        if (data) {
          setOrder({
            ...data,
            items: data.items as unknown as OrderItem[],
          });
        } else {
          setError('Order not found');
        }
      } catch (err) {
        console.error('Error fetching order:', err);
        setError('Failed to load order details');
      } finally {
        setLoading(false);
      }
    };

    fetchOrder();

    // Set up real-time subscription for order updates
    const channel = supabase
      .channel(`order-${orderId}`)
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'orders',
          filter: `id=eq.${orderId}`,
        },
        (payload) => {
          setOrder(prev => prev ? { ...prev, ...payload.new, items: payload.new.items as OrderItem[] } : null);
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [orderId]);

  const getCurrentStepIndex = () => {
    if (!order) return 0;
    const statusMap: Record<string, number> = {
      'pending': 0,
      'processing': 1,
      'out_for_delivery': 2,
      'completed': 3,
      'cancelled': -1,
    };
    return statusMap[order.status] ?? 0;
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-yellow-500/20 text-yellow-700';
      case 'processing': return 'bg-blue-500/20 text-blue-700';
      case 'out_for_delivery': return 'bg-purple-500/20 text-purple-700';
      case 'completed': return 'bg-green-500/20 text-green-700';
      case 'cancelled': return 'bg-red-500/20 text-red-700';
      default: return 'bg-gray-500/20 text-gray-700';
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar dark={true} onCartClick={() => {}} />
        <div className="container mx-auto px-4 pt-24 pb-12 flex items-center justify-center">
          <div className="flex items-center gap-2 text-muted-foreground">
            <Loader2 className="h-6 w-6 animate-spin" />
            <span>Loading order details...</span>
          </div>
        </div>
      </div>
    );
  }

  if (error || !order) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar dark={true} onCartClick={() => {}} />
        <div className="container mx-auto px-4 pt-24 pb-12 text-center">
          <Package className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
          <h1 className="text-2xl font-bold mb-2">Order Not Found</h1>
          <p className="text-muted-foreground mb-6">{error || 'The order you\'re looking for doesn\'t exist.'}</p>
          <Link to="/menu">
            <Button>Continue Shopping</Button>
          </Link>
        </div>
      </div>
    );
  }

  const currentStep = getCurrentStepIndex();

  return (
    <div className="min-h-screen bg-background">
      <Navbar dark={true} onCartClick={() => {}} />

      <div className="container mx-auto px-4 pt-24 pb-12">
        {/* Back Button */}
        <Link to="/account" className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground mb-6">
          <ArrowLeft className="h-4 w-4" />
          Back to Account
        </Link>

        {/* Order Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-8">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold">Track Order</h1>
            <p className="text-muted-foreground">Order #{order.id.slice(0, 8)}</p>
          </div>
          <Badge className={`${getStatusColor(order.status)} text-sm px-4 py-2`}>
            {order.status.replace('_', ' ').toUpperCase()}
          </Badge>
        </div>

        {/* Order Timeline */}
        {order.status !== 'cancelled' && (
          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Order Progress</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="relative">
                {/* Progress Line */}
                <div className="absolute left-6 top-0 bottom-0 w-0.5 bg-border" />
                <div 
                  className="absolute left-6 top-0 w-0.5 bg-primary transition-all duration-500"
                  style={{ height: `${Math.min(100, (currentStep / (orderSteps.length - 1)) * 100)}%` }}
                />

                {/* Steps */}
                <div className="space-y-8">
                  {orderSteps.map((step, index) => {
                    const isCompleted = index <= currentStep;
                    const isCurrent = index === currentStep;
                    
                    return (
                      <div key={step.key} className="relative flex items-start gap-4">
                        <div className={`
                          relative z-10 w-12 h-12 rounded-full flex items-center justify-center
                          ${isCompleted ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'}
                          ${isCurrent ? 'ring-4 ring-primary/20' : ''}
                          transition-all duration-300
                        `}>
                          {isCompleted && index < currentStep ? (
                            <CheckCircle2 className="h-6 w-6" />
                          ) : (
                            <step.icon className="h-6 w-6" />
                          )}
                        </div>
                        <div className="flex-1 pt-2">
                          <h3 className={`font-semibold ${isCompleted ? 'text-foreground' : 'text-muted-foreground'}`}>
                            {step.label}
                          </h3>
                          <p className="text-sm text-muted-foreground">{step.description}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Cancelled Order Message */}
        {order.status === 'cancelled' && (
          <Card className="mb-8 border-destructive">
            <CardContent className="pt-6">
              <div className="text-center text-destructive">
                <Package className="w-12 h-12 mx-auto mb-4" />
                <h3 className="font-semibold text-lg">Order Cancelled</h3>
                <p className="text-sm">This order has been cancelled</p>
              </div>
            </CardContent>
          </Card>
        )}

        <div className="grid md:grid-cols-2 gap-6">
          {/* Order Details */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                Order Details
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <p className="text-sm text-muted-foreground">Order Date</p>
                <p className="font-medium">{order.date} at {order.time}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Payment Method</p>
                <p className="font-medium capitalize">{order.payment_method}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Amount</p>
                <p className="text-2xl font-bold text-primary">Rs {order.total.toLocaleString()}</p>
              </div>
            </CardContent>
          </Card>

          {/* Delivery Details */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MapPin className="h-5 w-5" />
                Delivery Details
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <p className="text-sm text-muted-foreground">Customer Name</p>
                <p className="font-medium">{order.customer_name}</p>
              </div>
              <div className="flex items-start gap-2">
                <Phone className="h-4 w-4 mt-1 text-muted-foreground" />
                <p className="font-medium">{order.customer_contact}</p>
              </div>
              <div className="flex items-start gap-2">
                <MapPin className="h-4 w-4 mt-1 text-muted-foreground" />
                <p className="font-medium">{order.customer_address}</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Order Items */}
        <Card className="mt-6">
          <CardHeader>
            <CardTitle>Order Items ({order.items.length})</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {order.items.map((item, index) => (
                <div key={index} className="flex items-center gap-4 p-4 bg-muted/50 rounded-lg">
                  <img
                    src={item.image}
                    alt={item.name}
                    className="w-16 h-16 object-cover rounded-lg"
                  />
                  <div className="flex-1">
                    <h4 className="font-medium">{item.name}</h4>
                    <p className="text-sm text-muted-foreground">Qty: {item.quantity}</p>
                  </div>
                  <p className="font-semibold">Rs {(item.price * item.quantity).toLocaleString()}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Help Section */}
        <div className="mt-8 text-center">
          <p className="text-muted-foreground mb-4">Need help with your order?</p>
          <Link to="/#contact">
            <Button variant="outline">Contact Support</Button>
          </Link>
        </div>
      </div>
    </div>
  );
}