import { useState, useMemo } from 'react';
import { Navbar } from '@/components/Navbar';
import { HeroSlider } from '@/components/HeroSlider';
import { ProductCard } from '@/components/ProductCard';
import { CartDrawer } from '@/components/CartDrawer';
import { CheckoutModal } from '@/components/CheckoutModal';
import { OrderReceipt } from '@/components/OrderReceipt';
import { ContactSection } from '@/components/ContactSection';
import { Button } from '@/components/ui/button';
import { products } from '@/data/products';
import { Order } from '@/types/product';
import { ShoppingCart } from 'lucide-react';
import { useCart } from '@/contexts/CartContext';
import bannerFeatured from '@/assets/banner-featured.jpg';
import bannerPopular from '@/assets/banner-popular.jpg';
import bannerDesi from '@/assets/banner-desi.jpg';
import bannerBakery from '@/assets/banner-bakery.jpg';

export default function Index() {
  const [cartOpen, setCartOpen] = useState(false);
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [receiptOpen, setReceiptOpen] = useState(false);
  const [currentOrder, setCurrentOrder] = useState<Order | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const { getCartCount } = useCart();

  const filteredProducts = useMemo(() => {
    if (!searchQuery) return products;
    return products.filter(p => 
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.category.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [searchQuery]);

  const featuredProducts = filteredProducts.filter(p => p.category === 'featured');
  const popularProducts = filteredProducts.filter(p => p.category === 'popular');
  const fastFoodProducts = filteredProducts.filter(p => p.category === 'fastfood');
  const desiProducts = filteredProducts.filter(p => p.category === 'desi');
  const bakeryProducts = filteredProducts.filter(p => p.category === 'bakery');
  const readyToCookProducts = filteredProducts.filter(p => p.category === 'readytocook');

  const handleCheckout = () => {
    setCartOpen(false);
    setCheckoutOpen(true);
  };

  const handleOrderSuccess = (order: Order) => {
    setCurrentOrder(order);
    setReceiptOpen(true);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section with Navbar */}
      <section className="relative">
        <Navbar 
          onCartClick={() => setCartOpen(true)} 
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
        />
        <HeroSlider />
      </section>

      {/* Floating Cart Button */}
      <button
        onClick={() => setCartOpen(true)}
        className="fixed bottom-6 right-6 z-50 bg-primary hover:bg-primary/90 text-primary-foreground rounded-full p-4 shadow-lg transition-all hover:scale-110"
        aria-label="Open cart"
      >
        <ShoppingCart className="h-6 w-6" />
        {getCartCount() > 0 && (
          <span className="absolute -top-2 -right-2 bg-accent text-accent-foreground rounded-full w-7 h-7 flex items-center justify-center text-sm font-bold">
            {getCartCount()}
          </span>
        )}
      </button>

      {/* Intro Section */}
      <section className="py-16 bg-background" id="about">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-4xl md:text-5xl font-bold text-primary mb-6">
              Fast. Hygienic. Delicious.
            </h2>
            <p className="text-lg text-muted-foreground mb-8">
              Food Passion prepares home-style, hygienic meals and bakery items. Fast delivery,
              small-batch freshness, and dishes made with care.
            </p>
            <div className="flex flex-wrap gap-4 justify-center">
              <Button size="lg" variant="default" asChild>
                <a href="/menu">Explore Menu</a>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-16 bg-background" id="menu">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
            Featured Products
          </h2>
          {featuredProducts.length > 0 && (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-6">
              {featuredProducts.map(product => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Banner 1 */}
      <section className="py-0">
        <div className="container mx-auto px-4">
          <div className="aspect-[16/4] overflow-hidden rounded-lg">
            <img src={bannerFeatured} alt="Featured Products Banner" className="w-full h-full object-cover" />
          </div>
        </div>
      </section>

      {/* Popular Products */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
            Popular Products
          </h2>
          {popularProducts.length > 0 && (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-6">
              {popularProducts.map(product => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Banner 2 */}
      <section className="py-0">
        <div className="container mx-auto px-4">
          <div className="aspect-[16/4] overflow-hidden rounded-lg">
            <img src={bannerPopular} alt="Popular Products Banner" className="w-full h-full object-cover" />
          </div>
        </div>
      </section>

      {/* Fast Food */}
      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
            Fast Food
          </h2>
          {fastFoodProducts.length > 0 && (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-6">
              {fastFoodProducts.map(product => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Desi Food */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
            Desi Food
          </h2>
          {desiProducts.length > 0 && (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-6">
              {desiProducts.map(product => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Banner 3 */}
      <section className="py-0">
        <div className="container mx-auto px-4">
          <div className="aspect-[16/4] overflow-hidden rounded-lg">
            <img src={bannerDesi} alt="Desi Food Banner" className="w-full h-full object-cover" />
          </div>
        </div>
      </section>

      {/* Bakery */}
      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
            Cakes & Bakery
          </h2>
          {bakeryProducts.length > 0 && (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-6">
              {bakeryProducts.map(product => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Banner 4 */}
      <section className="py-0">
        <div className="container mx-auto px-4">
          <div className="aspect-[16/4] overflow-hidden rounded-lg">
            <img src={bannerBakery} alt="Bakery Banner" className="w-full h-full object-cover" />
          </div>
        </div>
      </section>

      {/* Ready to Cook */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
            Ready to Cook
          </h2>
          {readyToCookProducts.length > 0 && (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-6">
              {readyToCookProducts.map(product => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Contact Section */}
      <ContactSection />

      {/* Footer */}
      <footer className="bg-card border-t border-border py-12" id="contact">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h3 className="font-bold text-lg mb-4">MENU</h3>
              <ul className="space-y-2 text-muted-foreground">
                <li><a href="#menu" className="hover:text-primary">Burgers</a></li>
                <li><a href="#menu" className="hover:text-primary">Pizza</a></li>
                <li><a href="#menu" className="hover:text-primary">Desi Food</a></li>
                <li><a href="#menu" className="hover:text-primary">Cakes</a></li>
              </ul>
            </div>
            <div>
              <h3 className="font-bold text-lg mb-4">COMPANY</h3>
              <ul className="space-y-2 text-muted-foreground">
                <li><a href="#about" className="hover:text-primary">About Us</a></li>
                <li><a href="#contact" className="hover:text-primary">Contact</a></li>
              </ul>
            </div>
            <div>
              <h3 className="font-bold text-lg mb-4">SOCIAL</h3>
              <ul className="space-y-2 text-muted-foreground">
                <li><a href="#" className="hover:text-primary">Facebook</a></li>
                <li><a href="#" className="hover:text-primary">Instagram</a></li>
                <li><a href="#" className="hover:text-primary">YouTube</a></li>
              </ul>
            </div>
            <div>
              <h3 className="font-bold text-lg mb-4">CONTACT</h3>
              <ul className="space-y-2 text-muted-foreground">
                <li>+92 300 0000000</li>
                <li>info@foodpassion.com</li>
                <li>Lahore, Pakistan</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border pt-8 text-center text-muted-foreground">
            <p>© 2025 Food Passion - All Rights Reserved</p>
          </div>
        </div>
      </footer>

      {/* Cart Drawer */}
      <CartDrawer
        open={cartOpen}
        onClose={() => setCartOpen(false)}
        onCheckout={handleCheckout}
      />

      {/* Checkout Modal */}
      <CheckoutModal
        open={checkoutOpen}
        onClose={() => setCheckoutOpen(false)}
        onSuccess={handleOrderSuccess}
      />

      {/* Order Receipt */}
      <OrderReceipt
        open={receiptOpen}
        onClose={() => setReceiptOpen(false)}
        order={currentOrder}
      />
    </div>
  );
}
