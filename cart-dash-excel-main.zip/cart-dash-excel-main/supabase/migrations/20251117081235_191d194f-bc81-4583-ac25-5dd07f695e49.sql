-- Fix orders table RLS policies to require authentication
DROP POLICY IF EXISTS "Anyone can insert orders" ON public.orders;

-- Only authenticated users can insert orders
CREATE POLICY "Authenticated users can insert orders" 
ON public.orders 
FOR INSERT 
TO authenticated
WITH CHECK (true);

-- Admins can delete orders
CREATE POLICY "Admins can delete orders" 
ON public.orders 
FOR DELETE 
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role));

-- Update trigger - drop and recreate to avoid conflicts
DROP TRIGGER IF EXISTS update_orders_updated_at ON public.orders;
CREATE TRIGGER update_orders_updated_at
BEFORE UPDATE ON public.orders
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();