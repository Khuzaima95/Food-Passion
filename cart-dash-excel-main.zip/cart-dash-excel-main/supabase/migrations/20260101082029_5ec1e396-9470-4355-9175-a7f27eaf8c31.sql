-- Drop the existing restrictive INSERT policy and recreate as PERMISSIVE
DROP POLICY IF EXISTS "Authenticated users can insert their own orders" ON public.orders;

-- Create a PERMISSIVE INSERT policy (default behavior)
CREATE POLICY "Authenticated users can insert their own orders"
ON public.orders
FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = user_id);