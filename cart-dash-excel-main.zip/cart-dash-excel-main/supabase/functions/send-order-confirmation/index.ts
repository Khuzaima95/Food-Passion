import { serve } from "https://deno.land/std@0.190.0/http/server.ts";

const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY");

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface OrderItem {
  name: string;
  quantity: number;
  price: number;
}

interface OrderEmailRequest {
  orderId: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  customerAddress: string;
  items: OrderItem[];
  total: number;
  paymentMethod: string;
}

const handler = async (req: Request): Promise<Response> => {
  console.log("Received request to send order confirmation");

  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const orderData: OrderEmailRequest = await req.json();
    console.log("Order data received:", JSON.stringify(orderData));

    const {
      orderId,
      customerName,
      customerEmail,
      customerPhone,
      customerAddress,
      items,
      total,
      paymentMethod,
    } = orderData;

    // Build items HTML
    const itemsHtml = items
      .map(
        (item) => `
        <tr>
          <td style="padding: 12px; border-bottom: 1px solid #eee;">${item.name}</td>
          <td style="padding: 12px; border-bottom: 1px solid #eee; text-align: center;">${item.quantity}</td>
          <td style="padding: 12px; border-bottom: 1px solid #eee; text-align: right;">Rs. ${item.price.toFixed(2)}</td>
        </tr>
      `
      )
      .join("");

    const emailHtml = `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Order Confirmation</title>
        </head>
        <body style="margin: 0; padding: 0; font-family: Arial, sans-serif; background-color: #f5f5f5;">
          <div style="max-width: 600px; margin: 0 auto; background-color: #ffffff; padding: 40px;">
            <div style="text-align: center; margin-bottom: 30px;">
              <h1 style="color: #FF6B35; margin: 0;">🍕 Food Passion</h1>
              <p style="color: #666; margin-top: 10px;">Thank you for your order!</p>
            </div>
            
            <div style="background-color: #f8f9fa; border-radius: 8px; padding: 20px; margin-bottom: 30px;">
              <h2 style="color: #333; margin-top: 0;">Order #${orderId}</h2>
              <p style="color: #666; margin: 0;">Hello ${customerName},</p>
              <p style="color: #666;">Your order has been received and is being prepared with love!</p>
            </div>

            <div style="margin-bottom: 30px;">
              <h3 style="color: #333; border-bottom: 2px solid #FF6B35; padding-bottom: 10px;">Order Details</h3>
              <table style="width: 100%; border-collapse: collapse;">
                <thead>
                  <tr style="background-color: #f8f9fa;">
                    <th style="padding: 12px; text-align: left;">Item</th>
                    <th style="padding: 12px; text-align: center;">Qty</th>
                    <th style="padding: 12px; text-align: right;">Price</th>
                  </tr>
                </thead>
                <tbody>
                  ${itemsHtml}
                </tbody>
                <tfoot>
                  <tr>
                    <td colspan="2" style="padding: 12px; font-weight: bold; text-align: right;">Total:</td>
                    <td style="padding: 12px; font-weight: bold; text-align: right; color: #FF6B35;">Rs. ${total.toFixed(2)}</td>
                  </tr>
                </tfoot>
              </table>
            </div>

            <div style="margin-bottom: 30px;">
              <h3 style="color: #333; border-bottom: 2px solid #FF6B35; padding-bottom: 10px;">Delivery Information</h3>
              <p style="color: #666; margin: 5px 0;"><strong>Name:</strong> ${customerName}</p>
              <p style="color: #666; margin: 5px 0;"><strong>Phone:</strong> ${customerPhone}</p>
              <p style="color: #666; margin: 5px 0;"><strong>Address:</strong> ${customerAddress}</p>
              <p style="color: #666; margin: 5px 0;"><strong>Payment:</strong> ${paymentMethod === 'cod' ? 'Cash on Delivery' : paymentMethod}</p>
            </div>

            <div style="background-color: #fff3cd; border-radius: 8px; padding: 15px; margin-bottom: 30px;">
              <p style="color: #856404; margin: 0; font-size: 14px;">
                📞 We will contact you at <strong>${customerPhone}</strong> when your order is ready for delivery.
              </p>
            </div>

            <div style="text-align: center; color: #666; font-size: 12px; border-top: 1px solid #eee; padding-top: 20px;">
              <p>If you have any questions, please contact us at:</p>
              <p><strong>Phone:</strong> +92 300 0000000 | <strong>Email:</strong> info@foodpassion.com</p>
              <p style="margin-top: 20px;">© 2025 Food Passion - All Rights Reserved</p>
            </div>
          </div>
        </body>
      </html>
    `;

    console.log("Sending email to:", customerEmail);

    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${RESEND_API_KEY}`,
      },
      body: JSON.stringify({
        from: "Food Passion <onboarding@resend.dev>",
        to: [customerEmail],
        subject: `Order Confirmation #${orderId} - Food Passion`,
        html: emailHtml,
      }),
    });

    const emailResponse = await res.json();
    console.log("Email response:", emailResponse);

    if (!res.ok) {
      throw new Error(emailResponse.message || "Failed to send email");
    }

    return new Response(
      JSON.stringify({ success: true, emailResponse }),
      {
        status: 200,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  } catch (error: any) {
    console.error("Error in send-order-confirmation function:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);
